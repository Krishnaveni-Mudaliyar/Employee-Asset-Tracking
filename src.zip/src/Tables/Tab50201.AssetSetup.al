table 50201 "Asset Setup"
{
    Caption = 'Asset Setup';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Primary Key"; Code[10])
        {
            Caption = 'Primary Key';
            DataClassification = SystemMetadata;
        }
        field(10; "Asset Nos."; Code[20])
        {
            Caption = 'Asset Nos.';
            TableRelation = "No. Series".Code;
        }
        field(11; "Asset Request Nos."; Code[20])
        {
            Caption = 'Asset Request Nos.';
            TableRelation = "No. Series".Code;
        }
        field(12; "Assignment Nos."; Code[20])
        {
            Caption = 'Assignment Nos.';
            TableRelation = "No. Series".Code;
        }
        field(13; "Return Nos."; Code[20])
        {
            Caption = 'Return Nos.';
            TableRelation = "No. Series".Code;
        }
        field(14; "Transfer Nos."; Code[20])
        {
            Caption = 'Transfer Nos.';
            TableRelation = "No. Series".Code;
        }
        field(15; "Maintenance Nos."; Code[20])
        {
            Caption = 'Maintenance Nos.';
            TableRelation = "No. Series".Code;
        }
        field(16; "Disposal Nos."; Code[20])
        {
            Caption = 'Disposal Nos.';
            TableRelation = "No. Series".Code;
        }
        field(17; "Stocktake Nos."; Code[20])
        {
            Caption = 'Stocktake Nos.';
            TableRelation = "No. Series".Code;
        }
        field(20; "Warranty Alert Days"; Integer)
        {
            Caption = 'Warranty Alert Days';
            InitValue = 30;
            MinValue = 0;
        }
        field(21; "Warranty Alert User ID"; Code[50])
        {
            Caption = 'Warranty Alert User ID';
            TableRelation = User."User Name";
            ValidateTableRelation = false;
        }
    }
    keys
    {
        key(PK; "Primary Key")
        {
            Clustered = true;
        }
    }
}